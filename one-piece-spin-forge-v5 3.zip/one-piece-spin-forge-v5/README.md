# One Piece Spin Forge V5

A self-contained fan-made One Piece character/story spinner.

## Included
- Birth Island spin with island-weighted race probabilities
- Race, Haki, Devil Fruit, fighting style, faction, origin, and story systems
- Canon Devil Fruit registry embedded in the site
- Race and Devil Fruit buffs/debuffs
- No Devil Fruit outcome
- Branching life paths and career/event choices
- Story Mode with combat/training growth
- Mobile-friendly layout
- Built-in Feedback panel that packages the tester's feedback and current character build
- No server or database required for the core game

## Deploy
This is a static website. Upload the contents of this folder to GitHub Pages, Netlify, Vercel, Cloudflare Pages, or another static host. No build command is required.

### GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` (and optionally this README and `.nojekyll`) to the repository root.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main`, and choose `/ (root)`.
5. GitHub will provide the public URL.

### Netlify
Drag the `one-piece-spin-forge-v5` folder into Netlify's manual deploy area. Netlify will provide a public URL.

### Vercel
Import the folder/repository into Vercel. No build command is required.

## Feedback system
The in-game Feedback tab works immediately as a **feedback report generator**. It captures the feedback type, rating, message, optional name, character build, stats, and recent story events, then copies the report to the clipboard.

For automatic collection, create a form endpoint with a service such as Formspree or your own server, then set `FEEDBACK_ENDPOINT` near the bottom of `index.html` to that endpoint. Until an endpoint is configured, the game never uploads feedback anywhere.

## Notes
This is a fan-made project and is not affiliated with or endorsed by the creators or rights holders of One Piece.
